(() => {
'use strict';

const TILE = { WALL:0, FLOOR:1, STAIRS:2, EXIT:3 };
const DIRS = [[0,-1],[1,0],[0,1],[-1,0]];
const COLORS = {
  fog:'#050705', wall:'#283027', wall2:'#1b211b', floor:'#81785c', floor2:'#70674e', corridor:'#736b52', stairs:'#d7bd73',
  player:'#f3dfad', outline:'#151914', item:'#d7c770', trap:'#a24c3b', enemy:'#b25d4b'
};
const ITEM_DEFS = {
  coin:{name:'古銭',kind:'coin',glyph:'¤',desc:'拾うと所持金になる。'},
  onigiri:{name:'旅むすび',kind:'food',glyph:'●',desc:'満腹度を45回復する。'},
  bigOnigiri:{name:'大旅むすび',kind:'food',glyph:'◎',desc:'満腹度を80回復する。最大満腹度も少し伸びる。'},
  herb:{name:'命の草',kind:'herb',glyph:'✦',desc:'HPを25回復する。'},
  powerHerb:{name:'剛力草',kind:'herb',glyph:'✤',desc:'力を1上げる。'},
  confuseHerb:{name:'迷い草',kind:'herb',glyph:'※',desc:'飲むとしばらく混乱する。'},
  windScroll:{name:'風払いの札',kind:'scroll',glyph:'▤',desc:'部屋にいる敵を吹き飛ばしてダメージ。'},
  mapScroll:{name:'地読みの札',kind:'scroll',glyph:'▥',desc:'その階の地形をすべて明らかにする。'},
  sleepScroll:{name:'静寂の札',kind:'scroll',glyph:'▧',desc:'近くの敵を数ターン眠らせる。'},
  warpScroll:{name:'渡りの札',kind:'scroll',glyph:'▨',desc:'階のどこかへ瞬間移動する。'},
  healPot:{name:'癒しの壺',kind:'pot',glyph:'◉',desc:'3回までHPを18回復できる。',charges:3},
  sword1:{name:'旅人の刀',kind:'weapon',glyph:'†',desc:'攻撃+3',power:3},
  sword2:{name:'青嵐の刀',kind:'weapon',glyph:'†',desc:'攻撃+6',power:6},
  sword3:{name:'鬼灯丸',kind:'weapon',glyph:'†',desc:'攻撃+10',power:10},
  shield1:{name:'木編みの盾',kind:'shield',glyph:'◇',desc:'防御+2',power:2},
  shield2:{name:'鉄縁の盾',kind:'shield',glyph:'◆',desc:'防御+5',power:5},
  shield3:{name:'玄武の盾',kind:'shield',glyph:'◆',desc:'防御+8',power:8},
};
const ENEMY_DEFS = [
  {id:'mocchi',name:'モッチ',glyph:'●',baseHp:8,atk:4,def:0,xp:4,color:'#c77761',from:1,to:5,ai:'chase'},
  {id:'needle',name:'ハリネズ',glyph:'✹',baseHp:12,atk:6,def:1,xp:7,color:'#9f845d',from:3,to:9,ai:'chase'},
  {id:'bat',name:'ヨイヤミ',glyph:'⌁',baseHp:10,atk:7,def:0,xp:8,color:'#75628e',from:5,to:13,ai:'erratic'},
  {id:'boar',name:'ツノマル',glyph:'▲',baseHp:20,atk:10,def:2,xp:13,color:'#9d5d4b',from:8,to:18,ai:'charge'},
  {id:'mage',name:'灯し坊',glyph:'♢',baseHp:18,atk:9,def:2,xp:16,color:'#bc8d4d',from:11,to:24,ai:'ranged'},
  {id:'oni',name:'赤面鬼',glyph:'♠',baseHp:30,atk:14,def:4,xp:24,color:'#a64137',from:16,to:30,ai:'chase'},
  {id:'shade',name:'影法師',glyph:'✧',baseHp:24,atk:16,def:3,xp:27,color:'#4d5665',from:20,to:30,ai:'phase'},
  {id:'golem',name:'石王',glyph:'▣',baseHp:42,atk:18,def:7,xp:38,color:'#77766c',from:24,to:30,ai:'slow'},
];
const TRAP_TYPES = [
  {id:'spike',name:'棘罠',glyph:'×'}, {id:'hunger',name:'空腹罠',glyph:'△'}, {id:'warp',name:'飛ばし罠',glyph:'○'}, {id:'sleep',name:'眠り罠',glyph:'Z'}
];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const canvas = $('#gameCanvas'), ctx = canvas.getContext('2d');
const mini = $('#miniCanvas'), mctx = mini.getContext('2d');

let audioEnabled = true;
let audioCtx = null;
let game = null;
let toastTimer = null;

function rand(n){ return Math.floor(Math.random()*n); }
function chance(p){ return Math.random()<p; }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
function key(x,y){ return `${x},${y}`; }
function dist(a,b){ return Math.abs(a.x-b.x)+Math.abs(a.y-b.y); }
function pick(arr){ return arr[rand(arr.length)]; }
function deepClone(o){ return JSON.parse(JSON.stringify(o)); }

function beep(freq=440,dur=.05,type='square',vol=.025){
  if(!audioEnabled) return;
  try{
    audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();
    const o=audioCtx.createOscillator(),g=audioCtx.createGain(); o.type=type;o.frequency.value=freq;g.gain.value=vol;
    o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+dur);o.stop(audioCtx.currentTime+dur);
  }catch{}
}
function sfx(name){
  if(name==='step')beep(145,.025,'sine',.012); if(name==='hit'){beep(100,.04,'square',.04);setTimeout(()=>beep(78,.05,'square',.03),25)}
  if(name==='item')beep(680,.06,'triangle',.025); if(name==='stairs'){beep(330,.08,'triangle',.03);setTimeout(()=>beep(495,.11,'triangle',.03),70)}
  if(name==='hurt')beep(70,.12,'sawtooth',.035); if(name==='heal'){beep(520,.08,'sine',.025);setTimeout(()=>beep(660,.12,'sine',.025),60)}
  if(name==='death'){beep(140,.16,'sawtooth',.04);setTimeout(()=>beep(90,.3,'sawtooth',.035),120)}
}

function defaultMeta(){ return {bestFloor:0,bestLevel:1,clears:0,dex:{},runs:0}; }
function loadMeta(){ try{return {...defaultMeta(),...JSON.parse(localStorage.getItem('kaze_meta')||'{}')}}catch{return defaultMeta()} }
function saveMeta(meta){ localStorage.setItem('kaze_meta',JSON.stringify(meta)); }
function updateMetaUI(){ const m=loadMeta();$('#metaBestFloor').textContent=`${m.bestFloor||0}F`;$('#metaBestLevel').textContent=m.bestLevel||1;$('#metaClears').textContent=m.clears||0;$('#metaDex').textContent=Object.keys(m.dex||{}).length;$('#continueBtn').classList.toggle('hidden',!localStorage.getItem('kaze_save')); }

function newPlayer(){return {x:0,y:0,hp:24,maxHp:24,level:1,xp:0,nextXp:12,str:8,maxStr:8,hunger:100,maxHunger:100,gold:0,weapon:null,shield:null,inventory:[],confuse:0,sleep:0,kills:0};}
function makeAliases(){
  const herbs=['赤まだらの草','細葉の草','白露の草'];
  const scrolls=['煤けた札','青墨の札','裂けた札','金縁の札'];
  const herbIds=['herb','powerHerb','confuseHerb'].sort(()=>Math.random()-.5);
  const scrollIds=['windScroll','mapScroll','sleepScroll','warpScroll'].sort(()=>Math.random()-.5);
  const a={};herbIds.forEach((id,i)=>a[id]=herbs[i]);scrollIds.forEach((id,i)=>a[id]=scrolls[i]);return a;
}
function newGame(){
  const meta=loadMeta();meta.runs=(meta.runs||0)+1;saveMeta(meta);
  game={floor:1,turn:0,player:newPlayer(),map:[],rooms:[],enemies:[],items:[],traps:[],seen:new Set(),visible:new Set(),logs:[],identified:{},aliases:makeAliases(),floorMapped:false,rareFloor:false,runSeed:Date.now(),won:false};
  game.player.inventory.push(makeItem('onigiri'),makeItem('herb'));
  generateFloor(); showScreen('gameScreen'); renderAll(); log('旅が始まった。30階の最深部を目指そう。'); banner(game.rareFloor?'珍景 — 黄金の間':'壱ノ階 — 苔むす石窟'); saveRun();
}
function serializeGame(){ if(!game)return null;return {...game,seen:[...game.seen],visible:[...game.visible]}; }
function saveRun(){ if(game) localStorage.setItem('kaze_save',JSON.stringify(serializeGame())); }
function loadRun(){
  try{const raw=JSON.parse(localStorage.getItem('kaze_save')); if(!raw)return false;game=raw;game.aliases||=makeAliases();game.identified||={};game.seen=new Set(raw.seen||[]);game.visible=new Set(raw.visible||[]);showScreen('gameScreen');computeFov();renderAll();log('中断した旅を再開した。');return true}catch{return false}
}
function clearRun(){localStorage.removeItem('kaze_save');}

function makeItem(id){ const d=ITEM_DEFS[id]; return {uid:`i_${Date.now()}_${Math.random()}`,id,...deepClone(d),charges:d.charges||0,plus:0}; }
function itemKnown(i){return !game||!['herb','scroll'].includes(i.kind)||!!game.identified?.[i.id];}
function displayName(i){return itemKnown(i)?i.name:(game?.aliases?.[i.id]|| (i.kind==='herb'?'見知らぬ草':'見知らぬ札'));}
function itemLabel(i){ return `${displayName(i)}${i.plus?` +${i.plus}`:''}${i.kind==='pot'?` [${i.charges}]`:''}`; }

function generateFloor(){
  const W=45,H=45; game.map=Array.from({length:H},()=>Array(W).fill(TILE.WALL)); game.rooms=[];game.enemies=[];game.items=[];game.traps=[];game.floorMapped=false;game.rareFloor=game.floor>1&&game.floor<30&&chance(.07);
  const roomCount=8+rand(5);
  for(let attempt=0;attempt<160&&game.rooms.length<roomCount;attempt++){
    const w=5+rand(7),h=5+rand(7),x=2+rand(W-w-4),y=2+rand(H-h-4);const r={x,y,w,h,cx:x+Math.floor(w/2),cy:y+Math.floor(h/2)};
    if(game.rooms.some(o=>x<o.x+o.w+2&&x+w+2>o.x&&y<o.y+o.h+2&&y+h+2>o.y))continue;
    game.rooms.push(r);for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)game.map[yy][xx]=TILE.FLOOR;
  }
  game.rooms.sort((a,b)=>a.cx-b.cx);
  for(let i=1;i<game.rooms.length;i++) carveCorridor(game.rooms[i-1],game.rooms[i]);
  // add a couple loop corridors
  for(let i=0;i<2;i++){const a=pick(game.rooms),b=pick(game.rooms);if(a!==b)carveCorridor(a,b);}
  const start=game.rooms[0], end=game.rooms[game.rooms.length-1];game.player.x=start.cx;game.player.y=start.cy;game.map[end.cy][end.cx]=game.floor===30?TILE.EXIT:TILE.STAIRS;
  const occupied=new Set([key(game.player.x,game.player.y),key(end.cx,end.cy)]);
  const eCount=(game.rareFloor?2:5)+Math.floor(game.floor*.32)+rand(game.rareFloor?2:4);for(let i=0;i<eCount;i++){const p=randomFloor(occupied);if(!p)break;occupied.add(key(p.x,p.y));game.enemies.push(makeEnemy(p.x,p.y));}
  const itemCount=(game.rareFloor?11:5)+rand(game.rareFloor?5:4);for(let i=0;i<itemCount;i++){const p=randomFloor(occupied);if(!p)break;occupied.add(key(p.x,p.y));game.items.push({x:p.x,y:p.y,item:randomItem()});}
  const trapCount=Math.min(2+Math.floor(game.floor/3)+rand(3),12);for(let i=0;i<trapCount;i++){const p=randomFloor(occupied);if(!p)break;occupied.add(key(p.x,p.y));game.traps.push({x:p.x,y:p.y,type:pick(TRAP_TYPES),revealed:false,used:false});}
  if(game.floor%5===0){const p=randomFloor(occupied);if(p){game.items.push({x:p.x,y:p.y,item:makeItem(game.floor>=20?'sword3':game.floor>=10?'sword2':'sword1')});}}
  if(game.floor===30){
    const bossRoom=game.rooms[game.rooms.length-1];
    const boss={uid:'boss',x:bossRoom.cx,y:bossRoom.cy-2,id:'kazehami',name:'風喰ノ主',glyph:'王',hp:135,maxHp:135,atk:23,def:8,xp:120,color:'#8d3f35',ai:'chase',sleep:0,slowTick:false,boss:true};
    if(isWalkable(boss.x,boss.y)) game.enemies.push(boss);
  }
  game.seen=new Set();computeFov();
}
function carveCorridor(a,b){
  let x=a.cx,y=a.cy;const horizontalFirst=chance(.5);
  const carve=(tx,ty)=>{while(x!==tx||y!==ty){game.map[y][x]=TILE.FLOOR;if(x!==tx)x+=Math.sign(tx-x);else if(y!==ty)y+=Math.sign(ty-y);}game.map[y][x]=TILE.FLOOR;};
  if(horizontalFirst){carve(b.cx,y);carve(b.cx,b.cy)}else{carve(x,b.cy);carve(b.cx,b.cy)}
}
function randomFloor(occupied){for(let t=0;t<200;t++){const r=pick(game.rooms);const x=r.x+1+rand(Math.max(1,r.w-2)),y=r.y+1+rand(Math.max(1,r.h-2));if(game.map[y][x]===TILE.FLOOR&&!occupied.has(key(x,y))&&dist({x,y},game.player)>4)return{x,y}}return null;}
function randomItem(){
  const f=game.floor,r=Math.random();
  if(r<.10)return makeItem('coin');if(r<.23)return makeItem('onigiri');if(r<.29)return makeItem('bigOnigiri');if(r<.45)return makeItem('herb');if(r<.51)return makeItem('powerHerb');if(r<.56)return makeItem('confuseHerb');
  if(r<.63)return makeItem('windScroll');if(r<.69)return makeItem('mapScroll');if(r<.75)return makeItem('sleepScroll');if(r<.80)return makeItem('warpScroll');if(r<.85)return makeItem('healPot');
  if(r<.93)return makeItem(f>18?'sword3':f>7?'sword2':'sword1');return makeItem(f>18?'shield3':f>7?'shield2':'shield1');
}
function makeEnemy(x,y){
  const choices=ENEMY_DEFS.filter(e=>game.floor>=e.from&&game.floor<=e.to);const d=deepClone(pick(choices.length?choices:[ENEMY_DEFS[0]]));const scale=1+Math.max(0,game.floor-d.from)*.035;
  return {uid:`e_${Math.random()}`,x,y,id:d.id,name:d.name,glyph:d.glyph,hp:Math.round(d.baseHp*scale),maxHp:Math.round(d.baseHp*scale),atk:Math.round(d.atk*scale),def:d.def,xp:Math.round(d.xp*scale),color:d.color,ai:d.ai,sleep:0,slowTick:false};
}

function isWalkable(x,y){return y>=0&&x>=0&&y<game.map.length&&x<game.map[0].length&&game.map[y][x]!==TILE.WALL;}
function enemyAt(x,y){return game.enemies.find(e=>e.x===x&&e.y===y);}
function itemAt(x,y){return game.items.find(i=>i.x===x&&i.y===y);}
function trapAt(x,y){return game.traps.find(t=>t.x===x&&t.y===y&&!t.used);}
function currentRoom(pos=game.player){return game.rooms.find(r=>pos.x>=r.x&&pos.x<r.x+r.w&&pos.y>=r.y&&pos.y<r.y+r.h);}

function playerMove(dx,dy){
  if(!game||game.player.hp<=0)return;
  if(game.player.sleep>0){log('眠っていて動けない。');endTurn();return;}
  if(game.player.confuse>0&&chance(.55)){[dx,dy]=pick(DIRS);log('混乱して思う方向へ進めない！');}
  const nx=game.player.x+dx,ny=game.player.y+dy;if(!isWalkable(nx,ny)){sfx('step');return;}
  const e=enemyAt(nx,ny);if(e){playerAttack(e);endTurn();return;}
  game.player.x=nx;game.player.y=ny;sfx('step');checkTile();endTurn();
}
function playerAttack(e){
  const p=game.player,wp=p.weapon?(p.weapon.power+p.weapon.plus):0;const raw=p.str+wp+rand(4);const dmg=Math.max(1,raw-e.def-rand(2));e.hp-=dmg;sfx('hit');log(`${e.name}に${dmg}ダメージ！`);floatToast(`${dmg} DAMAGE`);
  if(e.hp<=0){game.enemies=game.enemies.filter(x=>x!==e);p.kills++;gainXp(e.xp);discover(`enemy:${e.id}`);log(`${e.name}を倒した。`,true);if(chance(.16))game.items.push({x:e.x,y:e.y,item:randomItem()});}
}
function gainXp(n){const p=game.player;p.xp+=n;while(p.xp>=p.nextXp){p.xp-=p.nextXp;p.level++;p.nextXp=Math.floor(p.nextXp*1.45+4);p.maxHp+=4+rand(3);p.hp=p.maxHp;p.str+=chance(.45)?1:0;log(`レベル${p.level}になった！ HPが全快した。`,true);sfx('heal');}}
function checkTile(){
  const p=game.player;const it=itemAt(p.x,p.y);if(it){if(it.item.kind==='coin'){const amount=30+rand(51)+game.floor*4;p.gold+=amount;game.items=game.items.filter(x=>x!==it);discover('item:coin');log(`古銭を${amount}G拾った。`);floatToast(`+${amount}G`);sfx('item');}else if(p.inventory.length<12){p.inventory.push(it.item);game.items=game.items.filter(x=>x!==it);discover(`item:${it.item.id}`);log(`${itemLabel(it.item)}を拾った。`);floatToast(`${displayName(it.item)} GET`);sfx('item');}else log('持ち物がいっぱいだ。');}
  const tr=trapAt(p.x,p.y);if(tr){tr.revealed=true;triggerTrap(tr);}
  const tile=game.map[p.y][p.x];if(tile===TILE.STAIRS)floatToast('階段だ。● / Space で降りる');if(tile===TILE.EXIT)floatToast('最深部の風門だ。● / Space で開く');
}
function contextAction(){
  if(!game)return;const tile=game.map[game.player.y][game.player.x];if(tile===TILE.STAIRS){descend();return;}if(tile===TILE.EXIT){winGame();return;}
  const it=itemAt(game.player.x,game.player.y);if(it){checkTile();renderAll();return;}waitTurn();
}
function descend(){game.floor++;sfx('stairs');log(`${game.floor}階へ降りる。`);generateFloor();banner(game.rareFloor?`珍景 — 黄金の間 / ${floorName(game.floor)}`:floorName(game.floor));if(game.floor===30)log('最深部に、巨大な気配がある……',true);endTurn(false);saveRun();}
function floorName(f){const names=['苔むす石窟','水音の回廊','狐火の洞','風鳴り坑','黒曜の深穴','忘れ路','骨灯の間','嵐喰らい','夜渡り層','無明の底'];return `${kanjiNum(f)}ノ階 — ${names[Math.min(names.length-1,Math.floor((f-1)/3))]}`;}
function kanjiNum(n){const a=['零','壱','弐','参','四','伍','六','七','八','九','拾','拾壱','拾弐','拾参','拾四','拾伍','拾六','拾七','拾八','拾九','弐拾','弐拾壱','弐拾弐','弐拾参','弐拾四','弐拾伍','弐拾六','弐拾七','弐拾八','弐拾九','参拾'];return a[n]||String(n)}

function waitTurn(){log('様子を見た。');endTurn();}
function endTurn(runEnemies=true){
  if(!game)return;game.turn++;const p=game.player;
  if(p.confuse>0)p.confuse--;if(p.sleep>0)p.sleep--;
  if(game.turn%10===0){p.hunger=Math.max(0,p.hunger-1);if(p.hunger===0){p.hp--;if(game.turn%20===0)log('空腹で体力が削られる…',true);}else if(game.turn%18===0&&p.hp<p.maxHp)p.hp++;}
  if(runEnemies) enemiesTurn();computeFov();renderAll();if(p.hp<=0)die('力尽きた');else saveRun();
}
function enemiesTurn(){
  const p=game.player;
  for(const e of [...game.enemies]){
    if(e.hp<=0)continue;if(e.sleep>0){e.sleep--;continue;}if(e.ai==='slow'){e.slowTick=!e.slowTick;if(e.slowTick)continue;}
    if(dist(e,p)===1){enemyAttack(e);continue;}
    if(e.ai==='ranged'&&dist(e,p)<=4&&sameLine(e,p)&&chance(.55)){const dmg=Math.max(1,e.atk-2-rand(3));damagePlayer(dmg,`${e.name}の火の粉`);continue;}
    if(e.ai==='charge'&&dist(e,p)<=5&&sameLine(e,p)&&lineClear(e,p)){let dx=Math.sign(p.x-e.x),dy=Math.sign(p.y-e.y);tryEnemyStep(e,dx,dy);if(dist(e,p)===1&&chance(.35))enemyAttack(e);continue;}
    if(e.ai==='phase'&&dist(e,p)<=7&&chance(.25)){const dx=Math.sign(p.x-e.x),dy=Math.sign(p.y-e.y);const nx=e.x+dx,ny=e.y+dy;if(!enemyAt(nx,ny)&&!(nx===p.x&&ny===p.y)&&ny>0&&nx>0&&ny<game.map.length-1&&nx<game.map[0].length-1){e.x=nx;e.y=ny;}continue;}
    if(dist(e,p)<=7&&hasLOS(e,p)){const [dx,dy]=pathStep(e,p);tryEnemyStep(e,dx,dy);}else if(e.ai==='erratic'||chance(.22)){const [dx,dy]=pick(DIRS);tryEnemyStep(e,dx,dy);}
  }
}
function sameLine(a,b){return a.x===b.x||a.y===b.y;}
function lineClear(a,b){let x=a.x,y=a.y,dx=Math.sign(b.x-a.x),dy=Math.sign(b.y-a.y);while(x!==b.x||y!==b.y){x+=dx;y+=dy;if((x!==b.x||y!==b.y)&&!isWalkable(x,y))return false;}return true;}
function hasLOS(a,b){const roomA=currentRoom(a),roomB=currentRoom(b);if(roomA&&roomA===roomB)return true;return dist(a,b)<=4&&lineClear(a,b);}
function pathStep(e,p){const opts=DIRS.map(d=>({dx:d[0],dy:d[1],score:Math.abs((e.x+d[0])-p.x)+Math.abs((e.y+d[1])-p.y)})).filter(o=>isWalkable(e.x+o.dx,e.y+o.dy)&&!enemyAt(e.x+o.dx,e.y+o.dy));opts.sort((a,b)=>a.score-b.score);return opts.length?[opts[0].dx,opts[0].dy]:[0,0];}
function tryEnemyStep(e,dx,dy){if(!dx&&!dy)return;const nx=e.x+dx,ny=e.y+dy;if(nx===game.player.x&&ny===game.player.y){enemyAttack(e);return;}if(isWalkable(nx,ny)&&!enemyAt(nx,ny)){e.x=nx;e.y=ny;}}
function enemyAttack(e){const sh=game.player.shield?(game.player.shield.power+game.player.shield.plus):0;const dmg=Math.max(1,e.atk-sh-rand(3));damagePlayer(dmg,`${e.name}の攻撃`);}
function damagePlayer(n,cause){const p=game.player;p.hp-=n;sfx('hurt');log(`${cause}！ ${n}ダメージ。`,true);floatToast(`-${n} HP`);if(p.hp<=0){p.hp=0;}}

function triggerTrap(t){const p=game.player;sfx('hurt');if(t.type.id==='spike'){damagePlayer(6+Math.floor(game.floor/3),'棘罠');}if(t.type.id==='hunger'){p.hunger=Math.max(0,p.hunger-20);log('空腹罠！ 満腹度が下がった。',true);}if(t.type.id==='warp'){warpPlayer();log('飛ばし罠！ 遠くへ飛ばされた。',true);}if(t.type.id==='sleep'){p.sleep=3;log('眠り罠！ 眠ってしまった。',true);}t.used=true;discover(`trap:${t.type.id}`);}
function warpPlayer(){const pos=randomFloor(new Set(game.enemies.map(e=>key(e.x,e.y))));if(pos){game.player.x=pos.x;game.player.y=pos.y;}}

function useItem(uid){const i=game.player.inventory.find(x=>x.uid===uid);if(!i)return;const p=game.player;let consumed=false;const wasKnown=itemKnown(i);
  if(i.kind==='food'){if(i.id==='bigOnigiri')p.maxHunger=Math.min(130,p.maxHunger+3);p.hunger=Math.min(p.maxHunger,p.hunger+(i.id==='bigOnigiri'?80:45));log(`${i.name}を食べた。`);sfx('heal');consumed=true;}
  else if(i.kind==='herb'){if(i.id==='herb'){p.hp=Math.min(p.maxHp,p.hp+25);log('傷が癒えた。');sfx('heal');}if(i.id==='powerHerb'){p.str++;p.maxStr++;log('力が湧いてきた！');sfx('heal');}if(i.id==='confuseHerb'){p.confuse=6;log('頭がぐるぐるする…');}consumed=true;}
  else if(i.kind==='scroll'){if(i.id==='windScroll'){for(const e of game.enemies.filter(e=>dist(e,p)<=7&&currentRoom(e)===currentRoom(p))){e.hp-=12+game.floor;if(e.hp<=0){p.kills++;gainXp(e.xp);}}game.enemies=game.enemies.filter(e=>e.hp>0);log('烈風が部屋を駆け抜けた！',true);sfx('hit');}if(i.id==='mapScroll'){for(let y=0;y<game.map.length;y++)for(let x=0;x<game.map[0].length;x++)if(game.map[y][x]!==TILE.WALL)game.seen.add(key(x,y));game.floorMapped=true;log('階の地形が頭に流れ込んだ。');}if(i.id==='sleepScroll'){for(const e of game.enemies.filter(e=>dist(e,p)<=5))e.sleep=5;log('周囲が静寂に包まれた。');}if(i.id==='warpScroll'){warpPlayer();log('風が身体をさらっていった。');}consumed=true;}
  else if(i.kind==='pot'){if(i.charges<=0){log('壺は空だ。');return;}p.hp=Math.min(p.maxHp,p.hp+18);i.charges--;log('壺の力で傷が癒えた。');sfx('heal');if(i.charges===0)log('壺の力は尽きた。');}
  else if(i.kind==='weapon'||i.kind==='shield'){equipItem(uid);return;}
  if(consumed){if(['herb','scroll'].includes(i.kind)&&!wasKnown){game.identified[i.id]=true;log(`正体は「${i.name}」だった。`,true);discover(`identified:${i.id}`);}removeInv(uid);}closeInventory();endTurn();
}
function equipItem(uid){const i=game.player.inventory.find(x=>x.uid===uid);if(!i)return;const slot=i.kind==='weapon'?'weapon':'shield';const old=game.player[slot];game.player[slot]=i;removeInv(uid);if(old)game.player.inventory.push(old);log(`${itemLabel(i)}を装備した。`);sfx('item');closeInventory();endTurn();}
function throwItem(uid){const i=game.player.inventory.find(x=>x.uid===uid);if(!i)return;let dir=lastFacing||[0,-1],x=game.player.x,y=game.player.y,hit=null;for(let n=0;n<6;n++){const nx=x+dir[0],ny=y+dir[1];if(!isWalkable(nx,ny))break;x=nx;y=ny;hit=enemyAt(x,y);if(hit)break;}removeInv(uid);if(hit){const dmg=5+(i.power||0);hit.hp-=dmg;log(`${i.name}を投げ、${hit.name}に${dmg}ダメージ。`);if(hit.hp<=0){game.player.kills++;gainXp(hit.xp);game.enemies=game.enemies.filter(e=>e!==hit);}}else game.items.push({x,y,item:i});closeInventory();endTurn();}
function dropItem(uid){const i=game.player.inventory.find(x=>x.uid===uid);if(!i)return;if(itemAt(game.player.x,game.player.y)){log('足元に物がある。');return;}removeInv(uid);game.items.push({x:game.player.x,y:game.player.y,item:i});log(`${i.name}を置いた。`);closeInventory();renderAll();}
function removeInv(uid){game.player.inventory=game.player.inventory.filter(x=>x.uid!==uid);}

function computeFov(){game.visible=new Set();const p=game.player;const r=currentRoom(p);if(r){for(let y=r.y-1;y<=r.y+r.h;y++)for(let x=r.x-1;x<=r.x+r.w;x++)if(y>=0&&x>=0&&y<game.map.length&&x<game.map[0].length){game.visible.add(key(x,y));game.seen.add(key(x,y));}}else{for(let y=p.y-2;y<=p.y+2;y++)for(let x=p.x-2;x<=p.x+2;x++)if(Math.abs(x-p.x)+Math.abs(y-p.y)<=3&&y>=0&&x>=0&&y<game.map.length&&x<game.map[0].length){game.visible.add(key(x,y));game.seen.add(key(x,y));}}
}

function renderAll(){if(!game)return;renderCanvas();renderMini();renderHud();renderLogs();}
function renderCanvas(){
  const W=canvas.width,H=canvas.height;ctx.clearRect(0,0,W,H);ctx.fillStyle='#070a07';ctx.fillRect(0,0,W,H);
  const cell=48,view=16;const p=game.player;let sx=p.x-Math.floor(view/2),sy=p.y-Math.floor(view/2);sx=clamp(sx,0,game.map[0].length-view);sy=clamp(sy,0,game.map.length-view);
  for(let vy=0;vy<view;vy++)for(let vx=0;vx<view;vx++){
    const x=sx+vx,y=sy+vy,k=key(x,y),seen=game.seen.has(k),vis=game.visible.has(k);if(!seen)continue;const px=vx*cell,py=vy*cell,t=game.map[y][x];
    drawTile(px,py,cell,t,vis,x,y);
    if(t===TILE.STAIRS&&vis)drawGlyph('≋',px,py,cell,COLORS.stairs);if(t===TILE.EXIT&&vis)drawGlyph('門',px,py,cell,'#d3af66');
    const trap=game.traps.find(t=>t.x===x&&t.y===y&&t.revealed&&!t.used);if(trap&&vis)drawGlyph(trap.type.glyph,px,py,cell,COLORS.trap,.72);
    const it=game.items.find(i=>i.x===x&&i.y===y);if(it&&vis){drawGlow(px+cell/2,py+cell/2,cell*.22,'rgba(229,204,109,.22)');drawGlyph(it.item.glyph,px,py,cell,COLORS.item,.92);}
  }
  for(const e of game.enemies){if(!game.visible.has(key(e.x,e.y)))continue;const vx=e.x-sx,vy=e.y-sy;if(vx<0||vy<0||vx>=view||vy>=view)continue;drawActor(e.glyph,vx*cell,vy*cell,cell,e.color,e.sleep>0?'Z':'');}
  const pvx=p.x-sx,pvy=p.y-sy;drawPlayer(pvx*cell,pvy*cell,cell);
  // vignette
  const g=ctx.createRadialGradient(W/2,H/2,W*.18,W/2,H/2,W*.69);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.58)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
}
function drawTile(px,py,s,t,vis,x,y){
  if(t===TILE.WALL){ctx.fillStyle=vis?COLORS.wall:COLORS.wall2;ctx.fillRect(px,py,s,s);ctx.fillStyle=vis?'rgba(255,255,255,.035)':'rgba(0,0,0,.06)';ctx.fillRect(px+2,py+2,s-4,7);if((x+y)%3===0){ctx.strokeStyle='rgba(0,0,0,.15)';ctx.beginPath();ctx.moveTo(px+9,py+s*.55);ctx.lineTo(px+s-6,py+s*.55);ctx.stroke();}}
  else{ctx.fillStyle=vis?((x+y)%2?COLORS.floor:COLORS.floor2):'#302f27';ctx.fillRect(px,py,s,s);ctx.strokeStyle=vis?'rgba(30,25,18,.14)':'rgba(0,0,0,.25)';ctx.strokeRect(px+.5,py+.5,s-1,s-1);if(vis&&((x*13+y*7)%11===0)){ctx.fillStyle='rgba(35,40,29,.22)';ctx.fillRect(px+7+(x%4)*5,py+12+(y%3)*6,2,2);}}
  if(!vis){ctx.fillStyle='rgba(4,6,4,.48)';ctx.fillRect(px,py,s,s);}
}
function drawGlyph(g,px,py,s,color,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.fillStyle=color;ctx.font=`700 ${Math.floor(s*.55)}px "Yu Mincho",serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(g,px+s/2,py+s/2+1);ctx.restore();}
function drawGlow(x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
function drawActor(g,px,py,s,color,status=''){drawGlow(px+s/2,py+s/2,s*.55,'rgba(0,0,0,.35)');ctx.fillStyle=color;ctx.beginPath();ctx.arc(px+s/2,py+s/2,s*.31,0,Math.PI*2);ctx.fill();ctx.lineWidth=2;ctx.strokeStyle='#191b17';ctx.stroke();ctx.fillStyle='#161813';ctx.font=`900 ${Math.floor(s*.42)}px serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(g,px+s/2,py+s/2+1);if(status){ctx.fillStyle='#ddd9c1';ctx.font='700 12px system-ui';ctx.fillText(status,px+s*.78,py+s*.18)}}
let lastFacing=[0,1];
function drawPlayer(px,py,s){const p=game.player;drawGlow(px+s/2,py+s/2,s*.7,'rgba(230,210,150,.16)');ctx.save();ctx.translate(px+s/2,py+s/2);ctx.fillStyle='#e5d5a5';ctx.strokeStyle='#252b21';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,-2,s*.27,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#40553e';ctx.beginPath();ctx.moveTo(-s*.22,-s*.2);ctx.lineTo(s*.22,-s*.2);ctx.lineTo(s*.12,-s*.35);ctx.lineTo(-s*.05,-s*.32);ctx.closePath();ctx.fill();ctx.fillStyle='#22261f';ctx.fillRect(-7,-4,4,4);ctx.fillRect(4,-4,4,4);if(p.weapon){ctx.strokeStyle='#d6c78d';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(s*.2,5);ctx.lineTo(s*.38,-s*.1);ctx.stroke();}ctx.restore();}
function renderMini(){const W=mini.width,H=mini.height;mctx.clearRect(0,0,W,H);mctx.fillStyle='#0c100c';mctx.fillRect(0,0,W,H);const mw=game.map[0].length,mh=game.map.length,s=Math.min(W/mw,H/mh);for(let y=0;y<mh;y++)for(let x=0;x<mw;x++){if(!game.seen.has(key(x,y)))continue;if(game.map[y][x]===TILE.WALL)continue;mctx.fillStyle='#766e57';mctx.fillRect(x*s,y*s,Math.max(1,s),Math.max(1,s));if(game.map[y][x]===TILE.STAIRS||game.map[y][x]===TILE.EXIT){mctx.fillStyle='#d9bd6e';mctx.fillRect(x*s,y*s,s*1.5,s*1.5);}}mctx.fillStyle='#f0e0a8';mctx.beginPath();mctx.arc((game.player.x+.5)*s,(game.player.y+.5)*s,Math.max(2,s*1.1),0,Math.PI*2);mctx.fill();}
function renderHud(){const p=game.player;$('#floorText').textContent=`${game.floor}F`;$('#levelText').textContent=p.level;$('#hpText').textContent=`${p.hp}/${p.maxHp}`;$('#hungerText').textContent=`${Math.floor(p.hunger)}/${p.maxHunger}`;$('#strText').textContent=p.str;$('#goldText').textContent=p.gold;$('#weaponText').textContent=p.weapon?itemLabel(p.weapon):'素手';$('#shieldText').textContent=p.shield?itemLabel(p.shield):'なし';$('#turnText').textContent=`${game.turn} turn`;$('#hpBar').style.width=`${p.hp/p.maxHp*100}%`;$('#hungerBar').style.width=`${p.hunger/p.maxHunger*100}%`;}
function renderLogs(){const el=$('#logList');el.innerHTML=game.logs.slice(-9).reverse().map(l=>`<div class="log-line ${l.hot?'hot':''}">${escapeHtml(l.text)}</div>`).join('');}
function log(text,hot=false){if(!game)return;game.logs.push({text,hot,turn:game.turn});if(game.logs.length>80)game.logs.shift();renderLogs();}
function floatToast(text){const el=$('#toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),1100);}
function banner(text){const el=$('#floorBanner');el.textContent=text;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1500);}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

function openInventory(){if(!game)return;renderInventory();$('#inventoryModal').classList.add('open');$('#inventoryModal').setAttribute('aria-hidden','false');}
function closeInventory(){$('#inventoryModal').classList.remove('open');$('#inventoryModal').setAttribute('aria-hidden','true');}
function renderInventory(){const p=game.player,el=$('#inventoryList');const all=[...(p.weapon?[{...p.weapon,equipped:'武器'}]:[]),...(p.shield?[{...p.shield,equipped:'盾'}]:[]),...p.inventory];if(!all.length){el.innerHTML='<div class="inv-item">持ち物はない。</div>';return;}el.innerHTML=all.map(i=>{
  const equipped=i.equipped;const usable=['food','herb','scroll','pot'].includes(i.kind);const equippable=['weapon','shield'].includes(i.kind)&&!equipped;
  return `<div class="inv-item"><div class="inv-top"><div><div class="inv-name">${escapeHtml(itemLabel(i))}</div><div class="inv-desc">${escapeHtml(itemKnown(i)?(i.desc||''):'効果は使うまでわからない。')}</div></div><span class="inv-badge">${equipped?`${equipped}装備中`:i.kind}</span></div>${!equipped?`<div class="inv-actions">${usable?`<button data-use="${i.uid}">使う</button>`:''}${equippable?`<button data-equip="${i.uid}">装備</button>`:''}<button data-throw="${i.uid}">投げる</button><button data-drop="${i.uid}">置く</button></div>`:''}</div>`;
}).join('');$$('[data-use]').forEach(b=>b.onclick=()=>useItem(b.dataset.use));$$('[data-equip]').forEach(b=>b.onclick=()=>equipItem(b.dataset.equip));$$('[data-throw]').forEach(b=>b.onclick=()=>throwItem(b.dataset.throw));$$('[data-drop]').forEach(b=>b.onclick=()=>dropItem(b.dataset.drop));}

function discover(id){const m=loadMeta();m.dex||={};m.dex[id]=true;saveMeta(m);}
function die(cause){if(!game)return;sfx('death');const m=loadMeta();m.bestFloor=Math.max(m.bestFloor||0,game.floor);m.bestLevel=Math.max(m.bestLevel||1,game.player.level);saveMeta(m);clearRun();showResult(false,cause);}
function winGame(){if(game.enemies.some(e=>e.boss&&e.hp>0)){log('風門は強大な風圧で閉ざされている。風喰ノ主を倒さなければ。',true);floatToast('主を倒せ');return;}game.won=true;const m=loadMeta();m.bestFloor=Math.max(m.bestFloor||0,30);m.bestLevel=Math.max(m.bestLevel||1,game.player.level);m.clears=(m.clears||0)+1;saveMeta(m);clearRun();sfx('stairs');showResult(true,'最深部の風門を開き、生還した。');}
function showResult(win,cause){$('#resultEyebrow').textContent=win?'THE WIND REMEMBERS YOUR NAME':'THE DUNGEON REMEMBERS';$('#resultTitle').textContent=win?'迷宮踏破！':'旅はここで終わった';$('#resultFloor').textContent=`${game.floor}F`;$('#resultLevel').textContent=game.player.level;$('#resultTurns').textContent=game.turn;$('#resultKills').textContent=game.player.kills;$('#resultCause').textContent=cause;showScreen('resultScreen');updateMetaUI();}
function showScreen(id){$$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));window.scrollTo({top:0,behavior:'smooth'});}

function keyboard(e){if(!game||!$('#gameScreen').classList.contains('active')||$('#inventoryModal').classList.contains('open'))return;const map={ArrowUp:[0,-1],w:[0,-1],W:[0,-1],ArrowDown:[0,1],s:[0,1],S:[0,1],ArrowLeft:[-1,0],a:[-1,0],A:[-1,0],ArrowRight:[1,0],d:[1,0],D:[1,0]};if(map[e.key]){e.preventDefault();lastFacing=map[e.key];playerMove(...map[e.key]);}else if(e.key===' '||e.key==='Enter'){e.preventDefault();contextAction();}else if(e.key==='i'||e.key==='I'){openInventory();}else if(e.key==='.'||e.key==='5'){waitTurn();}}

$('#startBtn').onclick=()=>newGame();$('#continueBtn').onclick=()=>loadRun();$('#inventoryBtn').onclick=openInventory;$('#mobileInventory').onclick=openInventory;$('#waitBtn').onclick=waitTurn;$('#mobileWait').onclick=waitTurn;$('#mobileAction').onclick=contextAction;
$('#saveQuitBtn').onclick=()=>{saveRun();game=null;showScreen('titleScreen');updateMetaUI();};
$('#retryBtn').onclick=()=>newGame();$('#titleBtn').onclick=()=>{game=null;showScreen('titleScreen');updateMetaUI();};
$('#soundBtn').onclick=()=>{audioEnabled=!audioEnabled;$('#soundBtn').textContent=audioEnabled?'♪':'×';};
$$('[data-close-modal]').forEach(b=>b.onclick=closeInventory);$$('[data-move]').forEach(b=>{b.onclick=()=>{const d=b.dataset.move.split(',').map(Number);lastFacing=d;playerMove(...d);};});
window.addEventListener('keydown',keyboard,{passive:false});
window.addEventListener('beforeunload',()=>{if(game&&game.player.hp>0)saveRun();});

// swipe controls on canvas
let touchStart=null;canvas.addEventListener('touchstart',e=>{if(e.touches.length===1)touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY,t:Date.now()};},{passive:true});
canvas.addEventListener('touchend',e=>{if(!touchStart)return;const t=e.changedTouches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;if(Math.hypot(dx,dy)<22){contextAction();touchStart=null;return;}const dir=Math.abs(dx)>Math.abs(dy)?[Math.sign(dx),0]:[0,Math.sign(dy)];lastFacing=dir;playerMove(...dir);touchStart=null;},{passive:true});

updateMetaUI();
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
})();
